import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sprout, Leaf, TrendingUp, Languages } from "lucide-react";
import SoilAnalysisForm from "@/components/SoilAnalysisForm";
import RecommendationResults from "@/components/RecommendationResults";
import { useLanguage } from "@/hooks/useLanguage";
import { Language } from "@/lib/translations";

const Index = () => {
  const [recommendation, setRecommendation] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const { language, setLanguage, t } = useLanguage();

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-accent/5 to-secondary/5">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-gradient-to-br from-primary to-primary/80">
                <Sprout className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-foreground">
                  {t('appName')} <span className="text-base font-normal text-muted-foreground">({t('appFullName')})</span>
                </h1>
                <p className="text-sm text-muted-foreground">{t('tagline')}</p>
              </div>
            </div>
            
            {/* Language Selector */}
            <div className="flex items-center gap-2">
              <Languages className="h-4 w-4 text-muted-foreground" />
              <Select value={language} onValueChange={(value) => setLanguage(value as Language)}>
                <SelectTrigger className="w-[140px] bg-background/50">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">🇬🇧 English</SelectItem>
                  <SelectItem value="hi">🇮🇳 हिन्दी</SelectItem>
                  <SelectItem value="es">🇪🇸 Español</SelectItem>
                  <SelectItem value="fr">🇫🇷 Français</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">
            {t('heroTitle')}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {t('heroDescription')}
          </p>
        </div>

        {/* Feature Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-12 max-w-5xl mx-auto">
          <Card className="p-6 bg-card/60 backdrop-blur-sm border-primary/20 hover:shadow-lg transition-all duration-300">
            <div className="p-3 rounded-lg bg-primary/10 w-fit mb-4">
              <Leaf className="h-6 w-6 text-primary" />
            </div>
            <h3 className="font-semibold text-lg mb-2">{t('soilAnalysisTitle')}</h3>
            <p className="text-sm text-muted-foreground">
              {t('soilAnalysisDesc')}
            </p>
          </Card>

          <Card className="p-6 bg-card/60 backdrop-blur-sm border-accent/20 hover:shadow-lg transition-all duration-300">
            <div className="p-3 rounded-lg bg-accent/10 w-fit mb-4">
              <Sprout className="h-6 w-6 text-accent" />
            </div>
            <h3 className="font-semibold text-lg mb-2">{t('aiRecommendationsTitle')}</h3>
            <p className="text-sm text-muted-foreground">
              {t('aiRecommendationsDesc')}
            </p>
          </Card>

          <Card className="p-6 bg-card/60 backdrop-blur-sm border-secondary/20 hover:shadow-lg transition-all duration-300">
            <div className="p-3 rounded-lg bg-secondary/10 w-fit mb-4">
              <TrendingUp className="h-6 w-6 text-secondary" />
            </div>
            <h3 className="font-semibold text-lg mb-2">{t('optimizeYieldTitle')}</h3>
            <p className="text-sm text-muted-foreground">
              {t('optimizeYieldDesc')}
            </p>
          </Card>
        </div>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto">
          {!recommendation ? (
            <SoilAnalysisForm 
              onSubmit={setRecommendation}
              isLoading={isLoading}
              setIsLoading={setIsLoading}
            />
          ) : (
            <RecommendationResults 
              recommendation={recommendation}
              onReset={() => setRecommendation(null)}
            />
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 bg-card/80 backdrop-blur-sm mt-16">
        <div className="container mx-auto px-4 py-6 text-center text-sm text-muted-foreground">
          <p>{t('footer')}</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
