import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Leaf, TrendingUp, Calendar, Lightbulb, Shield } from "lucide-react";
import { useLanguage } from "@/hooks/useLanguage";

interface RecommendationResultsProps {
  recommendation: {
    fertilizerType: string;
    npkRatio: string;
    applicationRate: string;
    applicationTiming: string;
    additionalTips: string[];
    environmentalImpact: string;
    expectedYieldIncrease: string;
  };
  onReset: () => void;
}

const RecommendationResults = ({ recommendation, onReset }: RecommendationResultsProps) => {
  const { t } = useLanguage();
  
  return (
    <div className="space-y-6">
      <Button 
        variant="outline" 
        onClick={onReset}
        className="mb-4 border-primary/30 hover:bg-primary/5"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        {t('newAnalysis')}
      </Button>

      {/* Main Recommendation Card */}
      <Card className="p-8 bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20 shadow-xl">
        <div className="flex items-start gap-4 mb-6">
          <div className="p-3 rounded-lg bg-primary/10">
            <Leaf className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-foreground mb-2">{t('recommendedFertilizer')}</h3>
            <p className="text-3xl font-bold text-primary">{recommendation.fertilizerType}</p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div className="p-4 rounded-lg bg-card/50 backdrop-blur-sm">
            <p className="text-sm text-muted-foreground mb-1">{t('npkRatio')}</p>
            <p className="text-2xl font-bold text-foreground">{recommendation.npkRatio}</p>
          </div>
          
          <div className="p-4 rounded-lg bg-card/50 backdrop-blur-sm">
            <p className="text-sm text-muted-foreground mb-1">{t('applicationRate')}</p>
            <p className="text-xl font-semibold text-foreground">{recommendation.applicationRate}</p>
          </div>
        </div>
      </Card>

      {/* Application Timing */}
      <Card className="p-6 bg-card/60 backdrop-blur-sm border-accent/20">
        <div className="flex items-start gap-3 mb-3">
          <Calendar className="h-6 w-6 text-accent mt-1" />
          <div>
            <h4 className="font-semibold text-lg text-foreground mb-2">{t('applicationTiming')}</h4>
            <p className="text-muted-foreground">{recommendation.applicationTiming}</p>
          </div>
        </div>
      </Card>

      {/* Expected Yield */}
      <Card className="p-6 bg-gradient-to-r from-secondary/10 to-secondary/5 border-secondary/20">
        <div className="flex items-start gap-3">
          <TrendingUp className="h-6 w-6 text-secondary mt-1" />
          <div>
            <h4 className="font-semibold text-lg text-foreground mb-2">{t('expectedResults')}</h4>
            <Badge className="bg-secondary text-secondary-foreground">
              {recommendation.expectedYieldIncrease}
            </Badge>
          </div>
        </div>
      </Card>

      {/* Additional Tips */}
      <Card className="p-6 bg-card/60 backdrop-blur-sm">
        <div className="flex items-start gap-3 mb-4">
          <Lightbulb className="h-6 w-6 text-primary mt-1" />
          <h4 className="font-semibold text-lg text-foreground">{t('additionalTips')}</h4>
        </div>
        <ul className="space-y-3">
          {recommendation.additionalTips.map((tip, index) => (
            <li key={index} className="flex items-start gap-3 text-muted-foreground">
              <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/10 text-primary text-sm font-semibold flex items-center justify-center mt-0.5">
                {index + 1}
              </span>
              <span>{tip}</span>
            </li>
          ))}
        </ul>
      </Card>

      {/* Environmental Impact */}
      <Card className="p-6 bg-gradient-to-r from-primary/5 to-accent/5 border-primary/20">
        <div className="flex items-start gap-3">
          <Shield className="h-6 w-6 text-primary mt-1" />
          <div>
            <h4 className="font-semibold text-lg text-foreground mb-2">{t('environmentalImpact')}</h4>
            <p className="text-muted-foreground">{recommendation.environmentalImpact}</p>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default RecommendationResults;
