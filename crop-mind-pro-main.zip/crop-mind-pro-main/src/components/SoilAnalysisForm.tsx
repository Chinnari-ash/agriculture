import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/hooks/useLanguage";
import { Loader2 } from "lucide-react";

interface SoilAnalysisFormProps {
  onSubmit: (data: any) => void;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
}

const SoilAnalysisForm = ({ onSubmit, isLoading, setIsLoading }: SoilAnalysisFormProps) => {
  const { toast } = useToast();
  const { t } = useLanguage();
  const [formData, setFormData] = useState({
    ph: "",
    nitrogen: "",
    phosphorus: "",
    potassium: "",
    soilType: "",
    organicMatter: "",
    cropType: "",
    growthStage: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke('fertilizer-recommendation', {
        body: {
          soilData: {
            ph: parseFloat(formData.ph),
            nitrogen: parseFloat(formData.nitrogen),
            phosphorus: parseFloat(formData.phosphorus),
            potassium: parseFloat(formData.potassium),
            soilType: formData.soilType,
            organicMatter: parseFloat(formData.organicMatter),
          },
          cropType: formData.cropType,
          growthStage: formData.growthStage,
        },
      });

      if (error) throw error;

      onSubmit(data.recommendation);
      toast({
        title: t('analysisComplete'),
        description: t('recommendationsReady'),
      });
    } catch (error: any) {
      console.error('Error getting recommendation:', error);
      toast({
        title: t('error'),
        description: error.message || t('errorMessage'),
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="p-8 bg-card/60 backdrop-blur-sm shadow-xl">
      <h3 className="text-2xl font-bold mb-6 text-foreground">{t('formTitle')}</h3>
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Soil Characteristics */}
        <div className="space-y-4">
          <h4 className="font-semibold text-lg text-foreground flex items-center gap-2">
            {t('soilCharacteristics')}
          </h4>
          
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="ph">{t('phLevel')}</Label>
              <Input
                id="ph"
                type="number"
                step="0.1"
                min="0"
                max="14"
                placeholder={t('phPlaceholder')}
                value={formData.ph}
                onChange={(e) => setFormData({ ...formData, ph: e.target.value })}
                required
                className="bg-background/50"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="nitrogen">{t('nitrogen')}</Label>
              <Input
                id="nitrogen"
                type="number"
                placeholder={t('nitrogenPlaceholder')}
                value={formData.nitrogen}
                onChange={(e) => setFormData({ ...formData, nitrogen: e.target.value })}
                required
                className="bg-background/50"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phosphorus">{t('phosphorus')}</Label>
              <Input
                id="phosphorus"
                type="number"
                placeholder={t('phosphorusPlaceholder')}
                value={formData.phosphorus}
                onChange={(e) => setFormData({ ...formData, phosphorus: e.target.value })}
                required
                className="bg-background/50"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="potassium">{t('potassium')}</Label>
              <Input
                id="potassium"
                type="number"
                placeholder={t('potassiumPlaceholder')}
                value={formData.potassium}
                onChange={(e) => setFormData({ ...formData, potassium: e.target.value })}
                required
                className="bg-background/50"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="soilType">{t('soilType')}</Label>
              <Select value={formData.soilType} onValueChange={(value) => setFormData({ ...formData, soilType: value })}>
                <SelectTrigger className="bg-background/50">
                  <SelectValue placeholder={t('selectSoilType')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="clay">{t('clay')}</SelectItem>
                  <SelectItem value="sandy">{t('sandy')}</SelectItem>
                  <SelectItem value="loamy">{t('loamy')}</SelectItem>
                  <SelectItem value="silty">{t('silty')}</SelectItem>
                  <SelectItem value="peaty">{t('peaty')}</SelectItem>
                  <SelectItem value="chalky">{t('chalky')}</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="organicMatter">{t('organicMatter')}</Label>
              <Input
                id="organicMatter"
                type="number"
                step="0.1"
                placeholder={t('organicMatterPlaceholder')}
                value={formData.organicMatter}
                onChange={(e) => setFormData({ ...formData, organicMatter: e.target.value })}
                required
                className="bg-background/50"
              />
            </div>
          </div>
        </div>

        {/* Crop Information */}
        <div className="space-y-4">
          <h4 className="font-semibold text-lg text-foreground">{t('cropInformation')}</h4>
          
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="cropType">{t('cropType')}</Label>
              <Select value={formData.cropType} onValueChange={(value) => setFormData({ ...formData, cropType: value })}>
                <SelectTrigger className="bg-background/50">
                  <SelectValue placeholder={t('selectCrop')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="wheat">{t('wheat')}</SelectItem>
                  <SelectItem value="rice">{t('rice')}</SelectItem>
                  <SelectItem value="corn">{t('corn')}</SelectItem>
                  <SelectItem value="soybean">{t('soybean')}</SelectItem>
                  <SelectItem value="cotton">{t('cotton')}</SelectItem>
                  <SelectItem value="potato">{t('potato')}</SelectItem>
                  <SelectItem value="tomato">{t('tomato')}</SelectItem>
                  <SelectItem value="sugarcane">{t('sugarcane')}</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="growthStage">{t('growthStage')}</Label>
              <Select value={formData.growthStage} onValueChange={(value) => setFormData({ ...formData, growthStage: value })}>
                <SelectTrigger className="bg-background/50">
                  <SelectValue placeholder={t('selectStage')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pre-planting">{t('prePlanting')}</SelectItem>
                  <SelectItem value="germination">{t('germination')}</SelectItem>
                  <SelectItem value="vegetative">{t('vegetative')}</SelectItem>
                  <SelectItem value="flowering">{t('flowering')}</SelectItem>
                  <SelectItem value="fruiting">{t('fruiting')}</SelectItem>
                  <SelectItem value="maturity">{t('maturity')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <Button 
          type="submit" 
          className="w-full bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 text-primary-foreground font-semibold py-6 text-lg"
          disabled={isLoading}
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              {t('analyzing')}
            </>
          ) : (
            t('submitButton')
          )}
        </Button>
      </form>
    </Card>
  );
};

export default SoilAnalysisForm;
