import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { soilData, cropType, growthStage } = await req.json();
    
    console.log('Received request:', { soilData, cropType, growthStage });

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    const systemPrompt = `You are an expert agricultural scientist specializing in soil science and precision farming. 
    Your role is to analyze soil data and provide specific, actionable fertilizer recommendations.
    
    Provide recommendations in the following JSON format:
    {
      "fertilizerType": "string (e.g., 'Balanced NPK', 'Nitrogen-Rich', 'Organic Compost')",
      "npkRatio": "string (e.g., '10-10-10', '20-10-5')",
      "applicationRate": "string (e.g., '150 kg/hectare', '200 lbs/acre')",
      "applicationTiming": "string (e.g., 'Apply 2 weeks before planting', 'Split application: 50% at planting, 50% at flowering')",
      "additionalTips": ["array of 3-4 specific tips"],
      "environmentalImpact": "string (brief note on environmental benefits)",
      "expectedYieldIncrease": "string (e.g., '15-20% increase expected')"
    }
    
    Base your recommendations on scientific principles of crop nutrition and sustainable agriculture.`;

    const userPrompt = `Analyze this agricultural data and provide fertilizer recommendations:
    
    Soil Characteristics:
    - pH Level: ${soilData.ph}
    - Nitrogen (N): ${soilData.nitrogen} ppm
    - Phosphorus (P): ${soilData.phosphorus} ppm
    - Potassium (K): ${soilData.potassium} ppm
    - Soil Type: ${soilData.soilType}
    - Organic Matter: ${soilData.organicMatter}%
    
    Crop Information:
    - Crop Type: ${cropType}
    - Growth Stage: ${growthStage}
    
    Provide a detailed, scientifically-backed fertilizer recommendation that will optimize yield while minimizing environmental impact.`;

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        response_format: { type: "json_object" },
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('AI API error:', response.status, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Rate limit exceeded. Please try again later.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: 'AI credits exhausted. Please add more credits.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      throw new Error(`AI API request failed: ${response.status}`);
    }

    const data = await response.json();
    console.log('AI response:', data);
    
    const recommendation = JSON.parse(data.choices[0].message.content);

    return new Response(
      JSON.stringify({ recommendation }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('Error in fertilizer-recommendation function:', error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : 'An unexpected error occurred' 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
